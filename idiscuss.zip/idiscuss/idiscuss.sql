-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 28, 2020 at 10:31 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `idiscuss`
--

-- --------------------------------------------------------

--
-- Table structure for table `cate`
--

CREATE TABLE `cate` (
  `id` int(8) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `created` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cate`
--

INSERT INTO `cate` (`id`, `name`, `description`, `created`) VALUES
(1, 'Python', 'Python is developed by Guido van Rossum.Guido van Rossum started implementing Python in 1989. Python is a very simple programming language so even if you are new to programming, you can learn python without facing any issues.', '2020-10-20 15:08:29'),
(2, 'Java', 'JAVA was developed by Sun Microsystems Inc in 1991, later acquired by Oracle Corporation. It was developed by James Gosling and Patrick Naughton. It is a simple programming language.  Writing, compiling and debugging a program is easy in java.  It helps t', '2020-10-20 15:08:29'),
(6, 'JavaScript', 'JavaScript was initially created to “make web pages alive”.\r\n\r\nThe programs in this language are called scripts. They can be written right in a web page’s HTML and run automatically as the page loads.\r\n\r\nScripts are provided and executed as plain text. Th', '2020-10-20 15:09:43'),
(7, 'flask', 'Flask has become popular among Python enthusiasts. As of October 2020, it has second most stars on GitHub among Python web-development frameworks, only slightly behind Django,[12] and was voted the most popular web framework in the Python Developers Surve', '2020-10-20 17:31:27'),
(9, 'C', 'The origin of C is closely tied to the development of the Unix operating system, originally implemented in assembly language on a PDP-7 by Dennis Ritchie and Ken Thompson, incorporating several ideas from colleagues. Eventually, they decided to port the o', '2020-10-27 12:05:38'),
(10, 'C++', 'C++ was designed with a bias toward system programming and embedded, resource-constrained software and large systems, with performance, efficiency, and flexibility of use as its design highlights.', '2020-10-27 12:11:31');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `comment_id` int(8) NOT NULL,
  `comment_content` text NOT NULL,
  `thread_id` int(8) NOT NULL,
  `comment_time` datetime NOT NULL DEFAULT current_timestamp(),
  `comment_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`comment_id`, `comment_content`, `thread_id`, `comment_time`, `comment_by`) VALUES
(1, 'ijrfp3f3ff', 1, '2020-10-20 15:33:32', 1),
(2, '', 1, '2020-10-20 15:33:41', 1),
(3, '', 1, '2020-10-20 15:33:47', 1),
(4, '', 1, '2020-10-20 15:33:49', 1),
(5, '', 1, '2020-10-20 15:33:51', 1),
(6, 'huihhhh', 5, '2020-10-20 17:34:32', 9),
(7, 'njijpkk', 1, '2020-10-20 17:35:19', 9),
(8, 'ytggtg', 17, '2020-10-22 19:42:24', 3);

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `email` varchar(25) NOT NULL,
  `msg` text NOT NULL,
  `date` datetime NOT NULL DEFAULT current_timestamp(),
  `id` int(7) NOT NULL,
  `name` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `threads`
--

CREATE TABLE `threads` (
  `thread_id` int(7) NOT NULL,
  `thread_title` varchar(255) NOT NULL,
  `thread_desc` text NOT NULL,
  `thread_cat_id` int(7) NOT NULL,
  `thread_user_id` int(7) NOT NULL,
  `timestamp` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `threads`
--

INSERT INTO `threads` (`thread_id`, `thread_title`, `thread_desc`, `thread_cat_id`, `thread_user_id`, `timestamp`) VALUES
(2, 'gg3', 'g3r', 2, 3, '2020-10-20 17:00:29'),
(5, 'avi', 'avi', 5, 9, '2020-10-20 17:34:03'),
(7, 'Raj', 'cw', 1, 3, '2020-10-21 14:12:30'),
(12, 'not', 'r', 7, 3, '2020-10-21 14:55:08'),
(13, 'no1', 'wer', 1, 3, '2020-10-21 16:36:23'),
(14, 'no2', 'vwrfw', 1, 3, '2020-10-21 16:36:29'),
(15, 'no3', 'fwf', 1, 3, '2020-10-21 16:36:34'),
(16, 'i have problem in ubuntu', 'ijviosdfv', 1, 3, '2020-10-21 18:46:12'),
(17, 'uyhy', 'uybyh', 8, 3, '2020-10-22 19:42:13');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `sno` int(8) NOT NULL,
  `useremail` varchar(30) NOT NULL,
  `user_pass` varchar(255) NOT NULL,
  `timestamp` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`sno`, `useremail`, `user_pass`, `timestamp`) VALUES
(1, '12', '$2y$10$L7vNCb0KWp.jZsRQdHATae5ypQmBd/KQTJhCkoWTx10Du.aJoMe7e', '2020-10-20 15:32:53'),
(2, 'wfwedwef', '$2y$10$qKl/z24UYlRd5GyOLBVRH.oh7CBaO23aCe.zGwxCtxXv9tb5W1w5a', '2020-10-20 15:35:07'),
(3, '45', '$2y$10$4AbR0AtdLxw6NGVKB3Eoh.OVNEugmuA32ChL68S5nEPH1JatTRaH6', '2020-10-20 15:43:36'),
(4, '', '$2y$10$8qEYz5LPvkhxpf89aRl2Netiqs9zkmJ8QJZJ5k2psk6ZgttdrQHoe', '2020-10-20 15:43:49'),
(5, '23', '$2y$10$dtnyGjYPFnqllC5jOarzHuJYcqAQ3fbCzvmb2Uw8XMDz7QFYDW0Gu', '2020-10-20 15:44:07'),
(6, '34', '$2y$10$sFF8O2WP9BhWXoSFrqQPl.eB0gsHj2CvkGQXYIJG/F.fxRXrgDMRS', '2020-10-20 15:44:49'),
(7, '78', '$2y$10$rGUUlyVfhVNhdefHNCfweuYktpCaLx1bFmzahi.lR/JsnoNj2k2gW', '2020-10-20 15:44:56'),
(8, '211', '$2y$10$EGqonhwhSgXM26R8cVvgX.ff6WvUlSgpfR8XkhxA0ad2fQxLEUmmW', '2020-10-20 17:15:30'),
(9, 'yh', '$2y$10$yONRZf7cBH3Uea.9Zi7p6.XpEpGNuiUl1hYHjkOq2m5D2B.TaE6ia', '2020-10-20 17:30:30'),
(10, 'yj', '$2y$10$02Vbllax3n43ApbwYEfLGOX0cmu4CKR5cxn3NjmHC9a4mb4QNL9fa', '2020-10-21 16:47:22');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cate`
--
ALTER TABLE `cate`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`comment_id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `threads`
--
ALTER TABLE `threads`
  ADD PRIMARY KEY (`thread_id`);
ALTER TABLE `threads` ADD FULLTEXT KEY `thread_title` (`thread_title`,`thread_desc`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`sno`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cate`
--
ALTER TABLE `cate`
  MODIFY `id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `comment_id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(7) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `threads`
--
ALTER TABLE `threads`
  MODIFY `thread_id` int(7) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `sno` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
